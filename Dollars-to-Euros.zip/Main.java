class Main {
  public static void main(String[] args) {
    double dollar = 775.90;
    double euro = dollar * 0.85;
    System.out.print(dollar + " dollar[s] is equal to " + euro + " Euro[s]");
  }
}